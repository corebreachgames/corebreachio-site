CORE BREACH / RUNEFALL — PRESS KIT

Studio: Core Breach
Website: https://corebreach.io/
Contact: support@corebreach.io

Core Breach is an independent game studio focused on atmospheric worlds and
deep systems. Runefall is currently in development. More games will follow.

RUNEFALL
Genre: Dark fantasy action survival
Status: In development
Release date: To be announced
Platforms in development: Windows, Linux, Android

Combine runestone skills, weapons, equipment, and a branching passive tree
to face growing hordes and bosses. Build a loadout, equip skill expansions,
and survive environments including forges, chapels, and catacombs.

WHAT IS INCLUDED
- Original company logo
- Five unlabelled screenshots: Forge combat, inventory and paper doll,
  Library, Castle, and the passive tree
- Runeweaver and Ember Glyph concept artwork
- The Forge menu illustration

Gameplay footage is available separately (silent, 30 seconds, 1280 x 720):
https://corebreach.io/assets/video/runefall-gameplay.mp4

The Forge and inventory images are staged captures from the actual development
project. The inventory includes empty slots and normal, magic, and rare gear.
The Forge uses four skills with expansions on skills, autoattack, and dash.
Gameplay footage uses an automated, invulnerable character in an isolated
development project, with reward modals suppressed for uninterrupted combat.
All development materials are subject to change.

USAGE
For editorial coverage, reviews, and creator videos. Credit Core Breach and
link to https://corebreach.io/. Preserve the logo's proportions and label
concept artwork clearly. Contact support@corebreach.io for other uses.
